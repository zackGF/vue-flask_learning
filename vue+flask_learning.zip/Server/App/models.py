from datetime import datetime
from passlib.apps import custom_app_context
from App import db


# 文章
class Article(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    title = db.Column(db.String(64))
    content = db.Column(db.Text)
    image = db.Column(db.String(255), nullable=True)
    ctime = db.Column(db.DateTime, default=datetime.now)
    status = db.Column(db.Boolean, default=True)
    message = db.relationship("Message", backref="article")

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'image': self.image,
            'ctime': self.ctime
        }


# 用户
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    email = db.Column(db.String(128), unique=True)
    password = db.Column(db.String(128))
    ctime = db.Column(db.DateTime, default=datetime.now)
    status = db.Column(db.Boolean, default=True)
    comments = db.relationship("Comments", backref="user")
    message = db.relationship("Message", backref="user")

    def hash_password(self, password):
        self.password = custom_app_context.encrypt(password)

    def verify_password(self, password):
        return custom_app_context.verify(password, self.password)


# 留言（不是文章评论）
class Comments(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    text = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.now)
    status = db.Column(db.Boolean, default=True)
    email = db.Column(db.String(128))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    admin_comments = db.relationship("AdminComments", backref="comments")

    def to_dict(self):
        return {
            'email': self.email,
            'text': self.text,
            'created_at': self.created_at.strftime('%Y-%m-%dT%H:%M:%SZ')
        }


# 文章评论
class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    email = db.Column(db.String(128))
    art_title = db.Column(db.String(64))
    message = db.Column(db.Text)
    status = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.now)

    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    art_id = db.Column(db.Integer, db.ForeignKey('article.id'))

    def to_dict(self):
        return {
            'email': self.email,
            # 'art_title': self.art_title,
            'text': self.message,
            'created_at': self.created_at.strftime('%Y-%m-%dT%H:%M:%SZ')
        }


class AdminComments(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    admintext = db.Column(db.Text)
    useremail = db.Column(db.String(128))
    status = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.now)

    coms_id = db.Column(db.Integer, db.ForeignKey('comments.id'))
    def to_dict(self):
        return {
            'ad_coms_text':self.admintext,
            'created_at': self.created_at.strftime('%Y-%m-%dT%H:%M:%SZ')
        }