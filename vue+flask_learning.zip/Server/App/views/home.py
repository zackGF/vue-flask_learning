from flask import Blueprint, jsonify, request, g
from flask_httpauth import HTTPTokenAuth
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer, SignatureExpired, BadSignature
from App import db
from App.models import Article, User, Comments, Message, AdminComments

# 蓝图
home = Blueprint('home', __name__)
# token令牌
s = Serializer('email', expires_in=300)
auth = HTTPTokenAuth('Bearer')


# 认证的回调函数
@auth.verify_token
def verify_token(token):
    try:
        data = s.loads(token)
    except SignatureExpired:
        return False
    except BadSignature:
        return False
    except:
        return False
    if 'email' in data:
        g.email = data['email']
        return True
    return False


@auth.error_handler
def error_handler():
    return jsonify({"code": 104, "msg": "未知错误"})


# 博客文章
# 首页 文章列表
@home.route("/")
def index():
    art_list = Article.query.filter_by(status=True).all()
    return jsonify([item.to_dict() for item in art_list])


# 文章详情
@home.route("/bloginfo")
def blog_info():
    id = request.args['blog']
    art_obj = Article.query.filter_by(id=id).first()
    return jsonify({"code": 102, "msg": "success",
                    "result": {"title": art_obj.title, "content": art_obj.content, "image": art_obj.image,
                               "time": art_obj.ctime}})
    # return "success"


# 文章评论
# 评论 get方式
@home.route("/blogmsg")
@auth.login_required
def blog_message_get():
    art_id = request.args['blog']
    msg_list = Message.query.filter_by(art_id=art_id).all()
    return jsonify([msg_obj.to_dict() for msg_obj in msg_list])


# 评论post 方式
@home.route("/blogmsg", methods=["POST"])
def blog_message_post():
    email = request.json['email']
    message = request.json['message']
    art_title = request.json['art_title']
    user_obj = User.query.filter_by(email=email).first()
    art_obj = Article.query.filter_by(title=art_title).first()
    if user_obj and art_obj:
        message_obj = Message(email=email, message=message, art_title=art_title, user_id=user_obj.id, art_id=art_obj.id)
        db.session.add(message_obj)
        db.session.commit()
        return jsonify(ok=True)
    else:
        return jsonify({"code": 104, "msg": "未知错误"})


# 用户管理
# 用户注册
@home.route("/register", methods=["POST"])
def user_register():
    email = request.json["email"]
    password = request.json["password"]
    if email is None or password is None:
        return jsonify({"code": 104, "msg": "邮箱密码不能为空"})
    if User.query.filter_by(email=email).first() is not None:
        return jsonify({"code": 104, "msg": "邮箱已存在"})
    user = User(email=email)
    user.hash_password(password)
    db.session.add(user)
    db.session.commit()
    return jsonify({"code": 102, "msg": "注册成功", "result": user.email})


# 用户登录
@home.route("/login", methods=["POST"])
def user_login():
    email = request.json['email']
    password = request.json['password']
    if email is None or password is None:
        return jsonify({"code": 104, "msg": "邮箱密码为空"})
    obj = User.query.filter_by(email=email).first()
    if not obj:
        return jsonify({"code": 104, "msg": "邮箱或密码错误"})
    if obj.verify_password(password):
        if obj.status:
            token = s.dumps({'email': email}).decode("utf-8")
            print(token)
            return jsonify({"code": 101, "msg": "成功", "user_token": token})
        else:
            return jsonify({"code": 5001, "msg": "当前账号已被封禁"})
    else:
        return jsonify({"code": 104, "msg": "邮箱密码错误"})


# 用户主页
@home.route("/userinfo")
@auth.login_required
def user_info():
    email = g.email
    obj = User.query.filter_by(email=email).first()
    if obj:
        return jsonify({"code": 102, "msg": "success", "result": {"account": obj.email, "time": obj.ctime}})


# 用户留言
# 留言 get方式
@home.route("/user_comments", methods=["POST"])
def user_comments_get():
    email = request.json['email']
    print(email)
    comments = Comments.query.filter_by(email=email).order_by(Comments.created_at.desc()).all()
    return jsonify([comment.to_dict() for comment in comments])


# 留言 post方式
@home.route("/usercomments", methods=["POST"])
def user_comments_post():
    email = request.json['email']
    text = request.json['text']
    if email == "" or text == "":
        return jsonify({"code": 104, "msg": "内容错误"})
    user_obj = User.query.filter_by(email=email).first()
    if user_obj:
        user_id = user_obj.id
        comments = Comments(text=text, email=email, user_id=user_id)
        db.session.add(comments)
        db.session.commit()
        return jsonify(ok=True)
    else:
        return jsonify({"code": 104, "msg": "未知错误"})


# 显示管理员回复的留言
@home.route("/admin2user", methods=["POST"])
@auth.login_required
def admin_to_user():
    email = request.json["email"]
    obj = AdminComments.query.filter_by(useremail=email).all()
    if not obj:
        return jsonify({"code": 104, "msg": "暂无评论回复"})
    return jsonify([item.to_dict() for item in obj])
