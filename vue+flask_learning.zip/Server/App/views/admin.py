from App import db
from App.models import Article, Comments, User, Message, AdminComments

from flask import Blueprint, render_template, session, redirect, url_for, request, jsonify

admin = Blueprint('admin', __name__)


# 管理员 主页
@admin.route("/admin_index")
def admin_index():
    admin_username = session.get('uuid')
    if admin_username:
        return render_template("admin/admin.html", username=admin_username)
    return "尚未登陆！"


# 管理员登陆 get方式
@admin.route("/login")
def login():
    # 判断是否已经登陆
    if 'uuid' in session:
        return redirect(url_for('admin.admin_index'))
    return render_template('admin/admin_login.html')


# 管理员登录 post方式
@admin.route("/admin_login", methods=["POST"])
def admin_login():
    admin_username = request.form.get("username")
    admin_password = request.form.get("password")
    if admin_username == "admin" and admin_password == "admin":
        session['uuid'] = admin_username
        return redirect(url_for('admin.admin_index'))
    return "用户名密码错误"


# 用户退出
@admin.route('/logout')
def admin_logout():
    session.pop('uuid', None)
    return redirect(url_for('admin.login'))


# 文章

# 评论信息
@admin.route('/msg_count/<int:uid>')
def admin_msg_info(uid):
    if not 'uuid' in session:
        return "尚未登陆！"
    msg_obj = Message.query.filter_by(art_id=uid).all()
    art_obj = Article.query.filter_by(id=uid).first()
    return render_template('admin/admin_messages_info.html', msg_list=msg_obj,
                           msg_row=len(msg_obj),
                           art_obj=art_obj)


# 删除评论
@admin.route('/msg_ban/<int:uid>')
def admin_msg_ban(uid):
    if not 'uuid' in session:
        return "尚未登陆！"
    art_id = request.args['art_id']
    msg_obj = Message.query.filter_by(id=uid).first()
    if msg_obj:
        msg_obj.status = False
        db.session.commit()
        return redirect(url_for('admin.admin_msg_info', uid=art_id))


# 恢复评论
@admin.route('/msg_rec/<int:uid>')
def admin_msg_rec(uid):
    if not 'uuid' in session:
        return "尚未登陆！"
    art_id = request.args['art_id']
    msg_obj = Message.query.filter_by(id=uid).first()
    if msg_obj:
        msg_obj.status = True
        db.session.commit()
        return redirect(url_for('admin.admin_msg_info', uid=art_id))


# 展示列表
@admin.route('/admin_article_list')
def article_list():
    if 'uuid' in session:
        art_list = Article.query.all()
        return render_template('admin/admin_article_list.html', art_list=art_list)
    return "尚未登陆！"


# 添加文章 get方式
@admin.route('/admin_article_create')
def article_create_get():
    if 'uuid' in session:
        return render_template('admin/admin_article_create.html')
    return "尚未登陆！"


# 添加文章 post方式
@admin.route('/admin_article_create', methods=["POST"])
def article_create_post():
    title = request.form["art_title"]
    content = request.form["art_content"]
    img = request.form["art_img_link"]
    if title == "" or content == "":
        return "fail"
    if img == "":
        img = "null"
        art = Article(title=title, content=content, image=img)
        print(title, content, img)
        db.session.add(art)
        db.session.commit()
        return redirect('/root/admin_article_list')
    art = Article(title=title, content=content, image=img)
    # print(title, content, img)
    db.session.add(art)
    db.session.commit()
    return redirect('/root/admin_article_list')


# 修改文章get
@admin.route("/admin_article_mod/<int:art_id>")
def article_mod_get(art_id):
    # 判断是否已经登陆
    if 'uuid' in session:
        art_obj = Article.query.filter_by(id=art_id).first()
        return render_template("admin/admin_article_mod.html", art_obj=art_obj)
    return "尚未登陆!"


# 修改文章 post
@admin.route("/admin_article_mod", methods=["POST"])
def article_mod_post():
    id = request.form['art_id']
    title = request.form["art_title"]
    content = request.form["art_content"]
    img = request.form["art_img_link"]
    # print(id,title,content,img)
    art_obj = Article.query.filter_by(id=id).first()
    if art_obj:
        art_obj.title = title
        art_obj.content = content
        art_obj.img = img
        db.session.commit()
        return redirect(url_for('admin.article_list'))
    return "fail"


# 更改文章显示状态
# 删除文章
@admin.route('/admin_article_del/<int:art_id>')
def articlt_del_get(art_id):
    if 'uuid' in session:
        art_obj = Article.query.filter_by(id=art_id).first()
        if art_obj:
            art_obj.status = False
            db.session.commit()
            return redirect(url_for('admin.article_list'))
        return "删除失败！未找到此文章"
    return "尚未登陆！"


# 恢复文章
@admin.route('/admin_article_restore/<int:art_id>')
def article_restore(art_id):
    if 'uuid' in session:
        art_obj = Article.query.filter_by(id=art_id).first()
        if art_obj:
            art_obj.status = True
            db.session.commit()
            return redirect(url_for('admin.article_list'))
        return "恢复失败！未找到此文章"
    return "尚未登陆！"


# 用户
# 用户管理页面
@admin.route('/admin_user')
def admin_user_list():
    if 'uuid' in session:
        user = User.query.all()
        return render_template('admin/admin_user.html', user_list=user)
    return "尚未登陆"


# 用户状态管理
# 用户封禁
@admin.route('/admin_user_ban')
def admin_user_ban():
    if 'uuid' in session:
        uid = request.args['userid']
        user = User.query.filter_by(id=uid).first()
        if user:
            user.status = False
            db.session.commit()
            return redirect(url_for('admin.admin_user_list'))
        return "禁封失败！"
    return "尚未登陆"


# 用户解封
@admin.route('/admin_user_act')
def admin_user_act():
    if 'uuid' in session:
        uid = request.args['userid']
        user = User.query.filter_by(id=uid).first()
        if user:
            user.status = True
            db.session.commit()
            return redirect(url_for('admin.admin_user_list'))
    return "尚未登陆"


# 留言
# 留言管理 用户名
@admin.route('/admin_comments')
def admin_comments():
    if 'uuid' in session:
        comments = Comments.query.with_entities(Comments.email).distinct().all()
        # <class 'sqlalchemy.util._collections.result'>
        list = [dict(zip(item.keys(), item)) for item in comments]
        return render_template('admin/admin_comments.html', comments_list=list)
    return "尚未登陆"


# 单独回复
@admin.route('/admin_user_comments')
def admin_user_comments():
    if 'uuid' not in session:
        return "尚未登陆"
    email = request.args['email']
    comments_list = Comments.query.filter_by(email=email).all()
    admin_comments_list = AdminComments.query.filter_by(useremail=email).all()
    return render_template("admin/admin_user_comments.html", comments_list=comments_list, ad_list=admin_comments_list)


# 删除留言
@admin.route('/com_ban/<int:uid>')
def admin_comments_ban(uid):
    if not 'uuid' in session:
        return "尚未登陆！"
    obj = Comments.query.filter_by(id=uid).first()
    if obj:
        obj.status = False
        db.session.commit()
        return redirect(url_for('admin.admin_comments'))


# 回复留言
@admin.route("/com_replay", methods=["POST"])
def admin_comments_replay():
    useremail = request.form['user_comments_email']
    admintext = request.form['comments_replay']
    user_obj = User.query.filter_by(email=useremail).first()
    if admintext == "":
        return "不能为空";
    if not user_obj:
        return "未知错误！"
    coms_id = user_obj.id
    admincoms_obj = AdminComments(admintext=admintext, coms_id=coms_id, useremail=useremail)
    db.session.add(admincoms_obj)
    db.session.commit()
    return redirect(url_for('admin.admin_user_comments', email=useremail))
