import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    Authorization: localStorage.getItem('Authorization') ? localStorage.getItem('Authorization') : ''
  },

  mutations:{
    changeLogin(state,user){
      state.Authorization = user.Authorization
      // console.log("授权");
      localStorage.setItem('Authorization',user.Authorization)
    },
    delLogin(state){
      state.Authorization = '';
      localStorage.removeItem('Authorization')
    }
  }
})
