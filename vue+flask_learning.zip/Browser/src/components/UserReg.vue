<template>
  <div>
    用户注册
    <div>
      <p style="color: orange">{{waring_info}}</p>
      <p><input type="email" v-model="email" placeholder="输入邮箱"></p>
      <p><input type="password" v-model="password" placeholder="输入密码"></p>
      <p><input type="password" v-model="password1" placeholder="输入密码"></p>
      <p>
        <button @click="DoUserReg">注册</button>
      </p>
    </div>
  </div>
</template>

<script>
  import axios from 'axios'

  export default {
    name: "UserReg",
    data() {
      return {
        email: '',
        password: '',
        password1: '',
        waring_info: ''
      }
    },
    methods: {
      DoUserReg() {
        let email = this.email;
        let password = this.password;
        let password1 = this.password1
        if (email.length < 3 || password.length < 3 || password1.length < 3) {
          alert("输入的信息长度不够");
          return
        }
        if (password1 != password) {
          this.waring_info = "两次密码不同";
          return;
        }
        axios({
          method: 'post',
          url: 'http://127.0.0.1:5000/register',
          data: {
            email: email,
            password: password
          }
        }).then(res => {
          if (res.data.code == 102) {
            this.$router.push("/mine")
            alert(res.data.msg + ",邮箱:" + res.data.result);
          } else {
            this.waring_info = res.data.msg;
            return
          }
        })
      }
    }
  }
</script>

<style scoped>

</style>
