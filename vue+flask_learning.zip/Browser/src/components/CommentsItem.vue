<template>
  <div>
    <p>{{comment.email}}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{comment.created_at | fromNow}}</p>
    <p v-html="comment.text"></p>
  </div>
</template>

<script>
  var moment = require('moment')
  export default {
    name: "comments",
    props: ['comment'],
    filters: {
      fromNow(time) {
        return moment(time).fromNow()
      }
    }
  }
</script>

<style scoped>

</style>
