<template>
  <div>
    用户登录
    <div>
      <p style="color: red">{{waring_info}}</p>
      <p>
        <input type="email" v-model="email" placeholder="输入邮箱">
      </p>
      <p>
        <input type="password" v-model="password" placeholder="输入密码">
      </p>
      <p>
        <button @click="DoUserLogin">登录</button>
      </p>
    </div>
  </div>
</template>

<script>
  import axios from 'axios'
  import {mapMutations} from 'vuex'
  export default {
    name: "UserLogin",
    data() {
      return {
        email:'',
        password:'',
        userToken:'',
        waring_info:''
      }
    },
    methods:{
      ...mapMutations(['changeLogin']),
      DoUserLogin(){
        let _this = this;
        axios.post("http://127.0.0.1:5000/login",{
          email:this.email,
          password:this.password
        }).then(res=>{
          if (res.data.code == 101) {
            // console.log('Bearer '+res.data.user_token);
            _this.userToken = 'Bearer '+res.data.user_token;
            _this.changeLogin({Authorization:_this.userToken});
            location.reload()
            alert("success")
          }else {
            this.waring_info = res.data.msg;
            return;
          }

        })
      }
    }
  }
</script>

<style scoped>

</style>
