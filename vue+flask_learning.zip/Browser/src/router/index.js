import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '@/components/HelloWorld'

import BlogIndex from '@/views/BlogIndex'
import BlogComments from '@/views/BlogComments'
import BlogMine from '@/views/BlogMine'
import BlogInfo from '@/views/BlogInfo'

import UserLogin from '@/components/UserLogin'
import UserReg from '@/components/UserReg'



Vue.use(Router);

export default new Router({
  mode:'history',
  routes: [
    {
      path: '/',
      name: 'BlogIndex',
      component: BlogIndex
    },
    {
      path:'/comments',
      component:BlogComments
    },
    {
      path:'/mine',
      component:BlogMine,
      children:[
        {
          path:'/',
          name:'UserLogin',
          component:UserLogin
        },
        {
          path:'/register',
          name:'UserReg',
          component:UserReg
        }
      ]
    },
    {
      path:'/bloginfo',
      name:'BlogInfo',
      component:BlogInfo
    }
  ]
})
