<template>
  <div>
    留言板
    <div>
      <div v-if="userIsLogin">
        <p v-model="email">
          {{email}}
        </p>
        <p>
          <textarea placeholder="输入内容" v-model="commentstext"></textarea>
        </p>
        <p>
          <button @click="onSubmit">提交留言</button>
        </p>
        <p>{{comments.length}}条留言</p>
        <div>
          <div v-for="comment in comments" style="border: 2px solid #000;margin-bottom: 10px">
            <!--        <p>{{comment}}</p>-->
            <comments-item :comment="comment"></comments-item>
          </div>
        </div>
        <hr>
        <div v-if="adcoms">
          <div v-for="adminitem in admincomments" style="border: 2px solid deepskyblue;margin-bottom: 10px">
            <p>管理员回复：&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{adminitem.created_at | fromNow}}</p>
            <p v-html="adminitem.ad_coms_text"></p>
          </div>
        </div>
        <div v-else>
          没有回复
        </div>
      </div>
      <div v-else>
        <p>尚未登录</p>
        <p>登录之后可查看留言</p>
      </div>
    </div>

  </div>
</template>

<script>
  import CommentsItem from '@/components/CommentsItem'
  import axios from 'axios'

  var moment = require('moment')

  export default {
    name: "BlogComments",
    filters: {
      fromNow(time) {
        return moment(time).fromNow()
      }
    },
    data() {
      return {
        userIsLogin: false,
        adcoms:true,
        email: '',
        commentstext: '',
        comments: [
          // {email: 'jack', text: 'ok，没问题', created_at: '2020-01-29T11:04:52.226Z'},
          // {email: 'Tom', text: '不ok，没问题', created_at: '2020-04-29T11:04:52.226Z'},
          // {email: 'Alex', text: 'ok，一切ok', created_at: '2020-01-19T11:04:52.226Z'}
        ],
        admincomments: [
          {ad_coms_text:'管理员暂无回复',created_at: '2020-01-29T11:04:52.226Z'}
        ]
      }
    },
    mounted() {
      axios.get('http://127.0.0.1:5000/userinfo').then(res => {
        if (res.data.code == 102) {
          this.userIsLogin = true;
          this.email = res.data.result.account
          axios({
            method: 'post',
            url: 'http://127.0.0.1:5000/user_comments',
            data: {
              'email': this.email
            }
          }).then(res => {
            // console.log(res.data);
            this.comments = res.data
          });
          axios({
            method: 'post',
            url: 'http://127.0.0.1:5000/admin2user',
            data: {
              'email': this.email
            }
          }).then(res => {
            // console.log(res.data);
            if (res.data.code == 104) {
              this.adcoms=false;
              return
            }
            this.admincomments = res.data;
          })
        } else {
          this.userIsLogin = false
        }
      });
    },
    methods: {
      onSubmit() {
        axios({
          method: 'post',
          url: 'http://127.0.0.1:5000/usercomments',
          data: {
            'email': this.email,
            'text': this.commentstext
          }
        }).then(res => {
          if (res.data.ok) {
            this.comments.unshift({
              email: this.email,
              text: this.commentstext,
              created_at: new Date().toISOString(),
            })
            this.commentstext = ''
          } else {
            alert(res.data.msg)
          }
        })
        // this.comments.unshift({
        //   email: this.email,
        //   text: this.commentstext,
        //   created_at: new Date().toISOString(),
        // })
        // // this.email = '';
        // this.commentstext = '';
      }
    },
    components: {
      CommentsItem
    }
  }
</script>

<style scoped>

</style>
