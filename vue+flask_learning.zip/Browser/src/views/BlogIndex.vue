<template>
  <div>
    <div v-for="(item,index) in art_list" :key="index">
      <div style="border: 2px solid #000;margin-bottom: 10px" @click="BlogInfo(item.id)">
        <p>{{item.title}}</p>
        <p>{{item.ctime}}</p>
        <p>
          <img :src="item.image" alt="">
        </p>
      </div>
    </div>
  </div>
</template>

<script>
  import axios from 'axios'
  export default {
    name: "Blog_index",
    data(){
      return{
        art_list:'',
      }
    },
    mounted() {
      axios.get('http://127.0.0.1:5000/').then(res=>{
        this.art_list = res.data
      })
    },
    methods:{
      BlogInfo(blog){
          this.$router.push({
            path:'/bloginfo',
            query:{
              id:blog
            }
          })
      }
    }
  }
</script>

<style scoped>

</style>
