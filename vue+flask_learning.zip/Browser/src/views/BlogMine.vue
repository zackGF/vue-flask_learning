<template>
  <div>
    我的
    <div v-if="userLogin">
      邮箱：{{useremail}}
      <button @click="LogOut">退出</button>
    </div>
    <div v-else>
      <router-link :to="{name:'UserLogin'}">登录</router-link>
      <router-link :to="{name: 'UserReg'}">注册</router-link>
      <div>
        <router-view></router-view>
      </div>
    </div>

  </div>
</template>

<script>
  import axios from 'axios'
  export default {
    name: "BlogMine",
    data() {
      return {
        userLogin: false,
        useremail: ''
      }
    },
    mounted() {
      axios("http://127.0.0.1:5000/userinfo").then(res => {
        if (res.data.code == 102) {
          this.userLogin = true;
          this.useremail = res.data.result.account;
        } else {
          this.userLogin = false;
        }
      })
    },
    methods:{
      LogOut(){
        this.$store.commit('delLogin');
        location.reload()
      }
    }
  }
</script>

<style scoped>

</style>
