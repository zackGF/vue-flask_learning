<template>
  <div>
    <p>{{title}}</p>
    <p>{{time}}</p>
    <p v-html="content">{{content}}</p>
    <p><img :src="image" alt=""> </p>
    <div v-if="userIsLogin">
      <p>当前用户：{{email}}</p>
      <p>
        <textarea placeholder="输入内容" v-model="messagetext"></textarea>
      </p>
      <p>
        <button @click="onMessage">发表言论</button>
      </p>
      <p>{{messages.length}}条评论</p>
      <div v-for="message in messages" style="border: 2px solid #000;margin-bottom: 10px">
        <p>{{message.email}}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{message.created_at | fromNow}}</p>
        <p v-html="message.text"></p>
      </div>
    </div>
    <div v-else>
      登录之后方可查看以及评论 <br>
      <button @click="toLogin">请登录</button>
    </div>
  </div>
</template>

<script>
  import axios from 'axios'

  var moment = require('moment')
  export default {
    name: "BlogInfo",
    filters: {
      fromNow(time) {
        return moment(time).fromNow()
      }
    },
    data() {
      return {
        id: 0,
        title: '',
        image: '',
        content: '',
        time: '',
        userIsLogin: false,
        email: '',
        messagetext: '',
        created_at: '',
        messages: [
          {email: 'jack', text: 'ok，没问题', created_at: '2020-01-29T11:04:52.226Z'},
          {email: 'Tom', text: '不ok，没问题', created_at: '2020-04-29T11:04:52.226Z'},
          {email: 'Alex', text: 'ok，一切ok', created_at: '2020-01-19T11:04:52.226Z'}
        ]
      }
    },
    created() {
      var id = this.$route.query.id;
      this.id = id
    },
    mounted() {
      axios.get('http://127.0.0.1:5000/bloginfo', {
        params: {
          blog: this.id
        }
      }).then(res => {
        if (res.data.code == 102) {
          this.title = res.data.result.title;
          this.image = res.data.result.image;
          this.content = res.data.result.content;
          this.time = res.data.result.time;
        }
      });
      axios.get('http://127.0.0.1:5000/userinfo').then(res => {
        if (res.data.code == 102) {
          this.userIsLogin = true;
          this.email = res.data.result.account
        } else {
          this.userIsLogin = false
        }
      });
      axios.get('http://127.0.0.1:5000/blogmsg',{
        params:{
          blog: this.id
        }
      }).then(res=>{
        // console.log(res.data);
        this.messages = res.data
      })

    },
    methods: {
      toLogin() {
        this.$router.push('/mine')
      },
      onMessage() {
        if (this.messagetext.length < 2) {
          alert("回复内容长度不足");
          return
        }
        axios({
          method:'post',
          url:'http://127.0.0.1:5000/blogmsg',
          data:{
            'email':this.email,
            // 'art_id':this.id,
            'art_title':this.title,
            'message':this.messagetext
          }
        }).then(res=>{
          if (res.data.ok) {
            this.messages.unshift({
              email:this.email,
              text:this.messagetext,
              created_at: new Date().toISOString(),
            });
            this.messagetext=""
          }else {
            alert(res.data.msg)
          }
        })
      }
    }

  }
</script>

<style scoped>

</style>
